from django.db import migrations
import csv
import os

def load_facilities_from_csv(apps, schema_editor):
    Facility = apps.get_model('private_healthcare_placement_optimization', 'Facility')
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    csv_path = os.path.join(BASE_DIR, '', 'facility_db.csv')  # Adjust the path if needed

    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        
        # Print column names to check for mismatches
        print("CSV Headers:", reader.fieldnames)
        
        for row in reader:
            phone_number = row['phone_number']
            # Truncate phone number if it's longer than 20 characters
            if len(phone_number) > 20:
                phone_number = phone_number[:20]

            Facility.objects.create(
                name=row['\ufeffname'],
                status=row.get('status', 'Active'),
                province=row['province'],
                city=row['city'],
                address=row['address'],
                facility_phone=row.get('facility_phone') or None,
                website=row.get('website') or None,
                person_in_charge=row['person_in_charge'],
                email=row['email'],
                phone_number=phone_number,
                designation=row['designation'],
                additional_requirements=row.get('additional_requirements') or None,
                shifts_available=row.get('shifts_available') or None,
                notes=row.get('notes') or None,
            )

class Migration(migrations.Migration):

    dependencies = [
        ('private_healthcare_placement_optimization', '0015_alter_facility_facility_phone'),
    ]

    operations = [
        migrations.RunPython(load_facilities_from_csv),
    ]
